const express = require('express');
const nodemailer = require('nodemailer');
const admin = require('firebase-admin');
const fs = require('fs');
const path = require('path');
const { Document, Packer, Paragraph } = require('docx');
const { exec } = require('child_process');
const cors = require('cors');

// Firebase setup
const serviceAccount = require('./firebaseConfig.json');  // Path to your Firebase service account JSON
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});
const db = admin.firestore();

const app = express();
app.use(express.json());
app.use(cors());  // Enable CORS to allow requests from frontend

// Function to send email with attachment
async function sendEmail(toEmail, subject, body, attachmentPath) {
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'sardar.hussyn@gmail.com',
      pass: 'your-gmail-app-password',  // Replace with actual Gmail App Password
    },
  });

  const mailOptions = {
    from: 'sardar.hussyn@gmail.com',
    to: toEmail,
    subject: subject,
    text: body,
    attachments: [
      {
        path: attachmentPath,
      },
    ],
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Email sent successfully');
  } catch (error) {
    console.error('Error sending email:', error);
  }
}

// Function to generate and send certificate
async function generateAndSendCertificate(userId) {
  const userDoc = await db.collection('users').doc(userId).get();
  if (!userDoc.exists) {
    return { status: 'error', message: `User ${userId} not found in Firebase.` };
  }

  const userData = userDoc.data();
  const name = userData.name;
  const email = userData.email;

  // Create DOCX certificate
  const doc = new Document({
    sections: [
      {
        properties: {},
        children: [
          new Paragraph({
            text: `Certificate for ${name}`,
            heading: 'Heading1',
          }),
          new Paragraph({
            text: `This certifies that ${name} has completed the required task.`,
          }),
        ],
      },
    ],
  });

  // Save the DOCX file
  const docPath = path.join(__dirname, 'Output', 'Doc', `${name}.docx`);
  const pdfPath = path.join(__dirname, 'Output', 'PDF', `${name}.pdf`);

  // Create necessary directories
  fs.mkdirSync(path.dirname(docPath), { recursive: true });
  fs.mkdirSync(path.dirname(pdfPath), { recursive: true });

  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(docPath, buffer);

  // Convert DOCX to PDF
  exec(`libreoffice --headless --convert-to pdf ${docPath} --outdir ${path.dirname(pdfPath)}`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error converting DOCX to PDF: ${stderr}`);
      return;
    }

    console.log(`Converted to PDF: ${stdout}`);

    // Send email with the PDF attachment
    sendEmail(email, 'Your Certificate', 'Attached is your certificate.', pdfPath);
  });

  return { status: 'success', message: `Certificate for ${name} sent to ${email}` };
}

// Endpoint to issue certificate
app.post('/issue_cert', async (req, res) => {
  try {
    const { user_id } = req.body;
    if (!user_id) {
      return res.status(400).json({ status: 'error', message: 'User ID is required.' });
    }

    const result = await generateAndSendCertificate(user_id);
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
});

// Start server
app.listen(5000, () => {
  console.log('Server running on http://localhost:5000');
});
