from flask import Flask, request, jsonify
import os
import firebase_admin
from firebase_admin import credentials, firestore
from docx import Document
from docx2pdf import convert
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
import re

from certificate_generator import docx_replace_regex

# Firebase setup
cred = credentials.Certificate("firebaseConfig.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

# Send email function
def send_email(to_email, subject, body, attachment_path):
    from_email = "sardar.hussyn@gmail.com"
    app_password = "axmm aayj djsd cqql"  # Use your generated App Password here

    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))
    
    with open(attachment_path, 'rb') as f:
        attach = MIMEApplication(f.read(), _subtype="pdf")
        attach.add_header('Content-Disposition', 'attachment', filename=os.path.basename(attachment_path))
        msg.attach(attach)

    try:
        # Set up the SMTP server
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.set_debuglevel(1)
        server.login(from_email, app_password)
        server.sendmail(from_email, to_email, msg.as_string())
        server.quit()
        print(f"Email sent successfully to {to_email}")
    except smtplib.SMTPAuthenticationError as e:
        print(f"Authentication failed: {str(e)}")
    except Exception as e:
        print(f"Error: {str(e)}")

# Function to generate certificate and send via email
def generate_and_send_certificate(user_id):
    user_ref = db.collection('users').document(user_id)
    user = user_ref.get()

    if user.exists:
        user_data = user.to_dict()
        name = user_data.get("name")
        email = user_data.get("email")

        # Ensure directories exist before saving files
        doc_output_dir = 'Output/Doc'
        pdf_output_dir = 'Output/PDF'
        os.makedirs(doc_output_dir, exist_ok=True)
        os.makedirs(pdf_output_dir, exist_ok=True)

        # Generate certificate document
        certificate_file = "Certificate.docx"  # Ensure this template file exists
        doc = Document(certificate_file)
        docx_replace_regex(doc, r"{Name Surname}", name)  # Replace name in the template

        output_docx_path = os.path.join(doc_output_dir, f'{name}.docx')
        doc.save(output_docx_path)

        # Convert to PDF
        pdf_path = os.path.join(pdf_output_dir, f'{name}.pdf')
        convert(output_docx_path, pdf_path)

        # Send email with the PDF attachment
        send_email(email, "Your Certificate", "Attached is your certificate.", pdf_path)
        return {"status": "success", "message": f"Certificate for {name} sent to {email}"}
    else:
        return {"status": "error", "message": f"User {user_id} not found in Firebase."}

# Flask setup
app = Flask(__name__)

@app.route('/issue_cert', methods=['POST'])
def issue_certificate():
    try:
        data = request.get_json()
        user_id = data.get("user_id")

        if not user_id:
            return jsonify({"status": "error", "message": "User ID is required."}), 400

        result = generate_and_send_certificate(user_id)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
